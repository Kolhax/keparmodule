# Example Package

Execute 
```
import keparmodule
keparmodule.help()
```
to see all the available commands <br>
i suggest you to update the package each time u will use it